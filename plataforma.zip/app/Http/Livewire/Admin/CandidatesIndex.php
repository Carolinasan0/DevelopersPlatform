<?php

namespace App\Http\Livewire\Admin;

use Livewire\Component;

class CandidatesIndex extends Component
{
    public function render()
    {
        return view('livewire.admin.candidates-index');
    }
}

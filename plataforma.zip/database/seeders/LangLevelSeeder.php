<?php

namespace Database\Seeders;

// use App\Models\Languaje_Level;

use Illuminate\Database\Seeder;
// use Illuminate\Support\Facades\DB;

class LangLevelSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // DB::table('languaje__levels')->insert([
        //     'level' => 'Nativo'
        // ]);

        // DB::table('languaje__levels')->insert([
        //     'level' => 'Básico'
        // ]);

        // DB::table('languaje__levels')->insert([
        //     'level' => 'Medio'
        // ]);

        // DB::table('languaje__levels')->insert([
        //     'level' => 'Avanzado'
        // ]);
    }
}

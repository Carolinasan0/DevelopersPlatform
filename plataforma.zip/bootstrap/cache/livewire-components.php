<?php return array (
  'admin.candidates-index' => 'App\\Http\\Livewire\\Admin\\CandidatesIndex',
  'admin.users-index' => 'App\\Http\\Livewire\\Admin\\UsersIndex',
  'admin.vacancies-index' => 'App\\Http\\Livewire\\Admin\\VacanciesIndex',
  'category-list' => 'App\\Http\\Livewire\\CategoryList',
  'footer' => 'App\\Http\\Livewire\\Footer',
  'navigation' => 'App\\Http\\Livewire\\Navigation',
  'vacancy-list' => 'App\\Http\\Livewire\\VacancyList',
);
<div class="bg-two shadow-lg rounded-lg text-center px-4 py-6">
    <a href="<?php echo e(route('vacancy.category', $category)); ?>">
        <h2 class="font-serif tracking-wide text-azul text-lg"><?php echo e($category->name); ?></h2>
    </a>
</div><?php /**PATH C:\xampp\htdocs\plataforma\resources\views/components/category-card.blade.php ENDPATH**/ ?>
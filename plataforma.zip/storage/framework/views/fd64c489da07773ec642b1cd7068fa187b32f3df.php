<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

  <?php $__env->startSection('content'); ?>

  <div class="text-center">
    <h1 class="font-serif tracking-wide text-3xl text-one mb-2 font-bold mt-10">Categorías</h1>
    <h3 class="font-sans text-base text-one">Revisa cuál es tu perfil, encuentra una vacante y ¡aplica ahora!</h3>
  </div>

  <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('category-list', [])->html();
} elseif ($_instance->childHasBeenRendered('ZRAAc0n')) {
    $componentId = $_instance->getRenderedChildComponentId('ZRAAc0n');
    $componentTag = $_instance->getRenderedChildComponentTagName('ZRAAc0n');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ZRAAc0n');
} else {
    $response = \Livewire\Livewire::mount('category-list', []);
    $html = $response->html();
    $_instance->logRenderedChild('ZRAAc0n', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

  <?php $__env->stopSection(); ?>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\plataforma\resources\views/category/category.blade.php ENDPATH**/ ?>
<div class="bg-two shadow-lg rounded-lg text-center px-4 py-6">
    <?php if(auth()->guard()->check()): ?>
    <a href="<?php echo e(route('vacancy', $vacancy->id)); ?>">
        <img src="<?php echo e($vacancy->user->avatar); ?>" class="rounded-full mx-auto h-16 w-16">
        <h2 class="font-serif tracking-wide text-azul text-lg"><?php echo e($vacancy->name); ?></h2>
        <p class="font-sans text-base text-azul"><?php echo e($vacancy->experience->experience); ?></p>
        <p class="font-sans text-base text-azul"><?php echo e($vacancy->salary->salary); ?></p>
        <p class="font-sans text-base text-azul"><?php echo e($vacancy->country->long_description); ?></p>
    </a>
    <?php else: ?>
    <a href="<?php echo e(route('login')); ?>">
        <img src="<?php echo e($vacancy->user->avatar); ?>" class="rounded-full mx-auto h-16 w-16">
        <h2 class="font-serif tracking-wide text-azul text-lg"><?php echo e($vacancy->name); ?></h2>
        <p class="font-sans text-base text-azul"><?php echo e($vacancy->experience->experience); ?></p>
        <p class="font-sans text-base text-azul"><?php echo e($vacancy->salary->salary); ?></p>
        <p class="font-sans text-base text-azul"><?php echo e($vacancy->country->long_description); ?></p>
    </a>
    <?php endif; ?>
</div><?php /**PATH C:\xampp\htdocs\plataforma\resources\views/components/vacancy-card.blade.php ENDPATH**/ ?>
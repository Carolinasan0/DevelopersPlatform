

<?php $__env->startSection('code', '404'); ?>
<?php $__env->startSection('title', __('Página no encontrada')); ?>

<?php $__env->startSection('image'); ?>
<img src="https://image.freepik.com/free-vector/error-404-concept-landing-page_52683-12188.jpg" class="img-fluid" alt="imagen error 404">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('message', __('Lo sentimos, la página que estás buscando no existe.')); ?>
<?php echo $__env->make('errors::illustrated-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\plataforma\resources\views/errors/404.blade.php ENDPATH**/ ?>
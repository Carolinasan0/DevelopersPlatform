<div class="card">

    <div class="card-header">
        <input wire:model="search" class="form-control" placeholder="Ingrese el nombre de una vacante">
    </div>

    <?php if($vacancies->count()): ?>

    <div class="card-body">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Estado</th>
                    <!-- <th>Candidatos</th> -->
                    <th colspan="2"></th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $vacancies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vacancy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($vacancy->id); ?></td>
                    <td><?php echo e($vacancy->name); ?></td>
                    <td><?php echo e($vacancy->status); ?></td>
                    <!-- <td>$vacancy-></td> -->

                    <td width="10px">
                        <a class="btn btn-dark btn-sm" href="<?php echo e(route('vacancy', $vacancy->id)); ?>">Ver</a>
                    </td>

                    <td width="10px">
                        <a class="btn btn-primary btn-sm" href="<?php echo e(route('admin.vacancies.edit', $vacancy)); ?>">Editar</a>
                    </td>
                    <td width="10px">
                        <form action="<?php echo e(route('admin.vacancies.destroy', $vacancy)); ?>" method="POST"></form>
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>

                        <button class="btn btn-danger btn-sm" type="submit">Eliminar</button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="div card-footer">
        <?php echo e($vacancies->links()); ?>

    </div>
    <?php else: ?>
    <div class="card-body">
        <strong>No existe ningún registro...</strong>
    </div>
    <?php endif; ?>
</div><?php /**PATH C:\xampp\htdocs\plataforma\resources\views/livewire/admin/vacancies-index.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title', 'ASPIREJOBS'); ?>

<?php $__env->startSection('content_header'); ?>

<a class="btn btn-secondary btn-sm float-right" href="<?php echo e(route('admin.vacancies.create')); ?>">Crear nueva vacante</a>
<h1>Listado de vacantes</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if(session('info')): ?>
<div class="alert alert-success">
    <strong><?php echo e(session('info')); ?></strong>
</div>
<?php endif; ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.vacancies-index')->html();
} elseif ($_instance->childHasBeenRendered('bTz4yDs')) {
    $componentId = $_instance->getRenderedChildComponentId('bTz4yDs');
    $componentTag = $_instance->getRenderedChildComponentTagName('bTz4yDs');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('bTz4yDs');
} else {
    $response = \Livewire\Livewire::mount('admin.vacancies-index');
    $html = $response->html();
    $_instance->logRenderedChild('bTz4yDs', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    console.log('Hi!');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\plataforma\resources\views/admin/vacancies/index.blade.php ENDPATH**/ ?>
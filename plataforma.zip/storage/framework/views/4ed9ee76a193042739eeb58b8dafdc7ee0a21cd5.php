

<?php $__env->startSection('title', 'ASPIREJOBS'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Lista de candidatos</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.candidates-index')->html();
} elseif ($_instance->childHasBeenRendered('eKkiLLA')) {
    $componentId = $_instance->getRenderedChildComponentId('eKkiLLA');
    $componentTag = $_instance->getRenderedChildComponentTagName('eKkiLLA');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('eKkiLLA');
} else {
    $response = \Livewire\Livewire::mount('admin.candidates-index');
    $html = $response->html();
    $_instance->logRenderedChild('eKkiLLA', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    console.log('Hi!');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\plataforma\resources\views/admin/candidates/index.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
    <div class="text-center">
      <h1 class="font-serif tracking-wide text-3xl text-one mb-2 font-bold mt-20">Categorías</h1>
      <h3 class="font-sans text-base text-one">Revisa cuál es tu perfil, encuentra una vacante y ¡aplica ahora!</h3>
    </div>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('vacancy-list', [])->html();
} elseif ($_instance->childHasBeenRendered('WZMXkJH')) {
    $componentId = $_instance->getRenderedChildComponentId('WZMXkJH');
    $componentTag = $_instance->getRenderedChildComponentTagName('WZMXkJH');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('WZMXkJH');
} else {
    $response = \Livewire\Livewire::mount('vacancy-list', []);
    $html = $response->html();
    $_instance->logRenderedChild('WZMXkJH', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\plataforma\resources\views/category.blade.php ENDPATH**/ ?>
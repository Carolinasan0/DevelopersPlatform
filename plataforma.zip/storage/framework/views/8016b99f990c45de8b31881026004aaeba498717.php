<div>
    <div class="card">

        <!-- FILTRO -->
        <div class="card-header">
            <input wire:model="search" class="form-control" placeholder="Buscar...">
            <!-- wire:model="search" se conecta con la función search de UsersIndex -->
        </div>

        <?php if($users->count()): ?>
        <!-- si encuentra coincidencia las irá mostrando si escribo algo que no existe, no arrojará resultados. -->
        <!-- TABLA DE DATOS -->
        <div class="card-body">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre completo</th>
                        <th>Email</th>
                        <!-- <th>Role</th> -->
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <!-- <td><?php echo e($user->roles); ?></td> -->
                        <td width="10px">
                            <a class="btn btn-primary btn-sm" href="<?php echo e(route('admin.users.edit', $user)); ?>">Editar</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <!-- PAGINACIÓN. Lo hace de 15 en 15 -->
        <div class="card-footer">
            <?php echo e($users->links()); ?>

        </div>

        <?php else: ?>

        <div class="card-body">
            <strong>No existen registros</strong>
        </div>

        <?php endif; ?>
    </div>
</div><?php /**PATH C:\xampp\htdocs\plataforma\resources\views/livewire/admin/users-index.blade.php ENDPATH**/ ?>
<div class="form-group">
    <?php echo Form::label('name', 'Título'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control', 'placeholder' => 'Ingrese el título de la vacante']); ?>


    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <small class="text-danger"><?php echo e($message); ?></small>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

</div>

<!-- SLUG -->
<div class="form-group">
    <?php echo Form::label('slug', 'Slug'); ?>

    <?php echo Form::text('slug', null, ['class' => 'form-control', 'placeholder' => 'Este es el slug de la vacante', 'readonly']); ?>


    <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <small class="text-danger"><?php echo e($message); ?></small>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

</div>

<!-- CATEGORÍA -->
<div class="form-group">
    <?php echo Form::label('category_id', 'Categoría'); ?>

    <?php echo Form::select('category_id', $categories, null, ['class' => 'form-control']); ?>


    <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <small class="text-danger"><?php echo e($message); ?></small>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

</div>

<!-- ESTADO -->
<div class="form-group">
    <p class="font-weight-bold">Estado</p>
    <label class="mr-2">
        <?php echo Form::radio('status', 'Borrador', true); ?>

        Borrador
    </label>

    <label class="mr-2">
        <?php echo Form::radio('status', 'Publicar'); ?>

        Publicar
    </label>

    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <br>
    <small class="text-danger"><?php echo e($message); ?></small>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

</div>

<!-- DESCRIPCIÓN -->
<div class="form-group">
    <?php echo Form::label('description', 'Descripción del cargo'); ?>

    <?php echo Form::textarea('description', null, ['class' => 'form-control']); ?>


    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <small class="text-danger"><?php echo e($message); ?></small>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<!-- PAÍS -->
<div class="form-group">
    <?php echo Form::label('country_id', 'Departamento'); ?>

    <?php echo Form::select('country_id', $countries, null, ['class' => 'form-control']); ?>


    <?php $__errorArgs = ['country_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <small class="text-danger"><?php echo e($message); ?></small>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

</div>

<!-- RANGO SALARIAL -->
<div class="form-group">
    <?php echo Form::label('salary_id', 'Rango salarial'); ?>

    <?php echo Form::select('salary_id', $wages, null, ['class' => 'form-control']); ?>


    <?php $__errorArgs = ['salary_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <small class="text-danger"><?php echo e($message); ?></small>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

</div>

<!-- TIPO MONEDA -->
<div class="form-group">
    <?php echo Form::label('currency_id', 'Tipo de moneda'); ?>

    <?php echo Form::select('currency_id', $currencies, null, ['class' => 'form-control']); ?>


    <?php $__errorArgs = ['currency_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <small class="text-danger"><?php echo e($message); ?></small>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

</div>

<!-- TIEMPO DE EXPERIENCIA -->
<div class="form-group">
    <?php echo Form::label('experience_id', 'Experiencia requerida'); ?>

    <?php echo Form::select('experience_id', $experiences, null, ['class' => 'form-control']); ?>


    <?php $__errorArgs = ['experience_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <small class="text-danger"><?php echo e($message); ?></small>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

</div>

<!-- TECNOLOGÍAS -->
<div class="form-group">
    <p class="font-weight-bold">Tecnologías requeridas</p>

    <?php $__currentLoopData = $tecnologies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tecnology): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <label class="mr-2">
        <?php echo Form::checkbox('tecnologies[]', $tecnology->id, null); ?>

        <?php echo e($tecnology->name); ?>

    </label>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php $__errorArgs = ['tecnologies'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <br>
    <small class="text-danger"><?php echo e($message); ?></small>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<!-- FECHA FINAL -->
<div class="form-group">
    <?php echo Form::label('end', 'Fecha limite de postulación (MM/DD/AAAA)'); ?>

    <?php echo Form::textarea('end', null, ['class' => 'form-control']); ?>


    <?php $__errorArgs = ['end'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <small class="text-danger"><?php echo e($message); ?></small>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

</div><?php /**PATH C:\xampp\htdocs\plataforma\resources\views/admin/vacancies/partials/form.blade.php ENDPATH**/ ?>
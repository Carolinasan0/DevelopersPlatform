<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

   <?php $__env->startSection('content'); ?>
   <div class="text-center">
      <h1 class="font-serif tracking-wide text-3xl text-one mb-2 font-bold mt-10">Detalle de la vacante</h1>
   </div>

   <div class="bg-gray-100 text-left grid lg:grid-cols-2 md:grid-cols-2 grid-cols-1 gap-4 mt-8 mx-20 pb-10">
      <div class="col-span-1">
         <img src="<?php echo e($vacancy->user->avatar); ?>" class="rounded-full mr-2 h-14 w-14 mb-6 mt-8">
         <h1 class="text-azul font-serif text-2xl mb-8"><?php echo e($vacancy->name); ?></h1>
         <div class="mb-6">
            <p class="font-bold font-sans text-azul">Experiencia requerida: </p>
            <?php echo e($vacancy->experience->experience); ?>

         </div>
         <div class="mb-6">
            <p class="font-bold font-sans text-azul">Rango salarial: </p>
            <?php echo e($vacancy->salary->salary); ?>

         </div>
         <div class="mb-6">
            <p class="font-bold font-sans text-azul">Descripción de la vacante: </p>
            <?php echo e($vacancy->description); ?>

         </div>
      </div>

      <div class="col-span-1 lg:mt-40 lg:ml-10">
         <div class="mb-6">
            <p class="font-bold font-sans text-azul">Tecnologías requeridas: </p>
            <?php $__currentLoopData = $vacancy->tecnologies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tecnology): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="inline-block px-3 h-6 bg-gray-600 text-white rounded-full"><?php echo e($tecnology->name); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </div>
         <div class="mb-6">
            <p class="font-bold font-sans text-azul">Ubicación: </p>
            <?php echo e($vacancy->country->long_description); ?>

         </div>
         <div class="mb-6">
            <p class="font-bold font-sans text-azul">Fecha límite: </p>
            <?php echo e($vacancy->end); ?>

         </div>

         <?php if(Auth::user()->hasRole('Desarrollador')): ?>
         <!-- Role -> Desarrollador -> mostrar alerta de aplicado. -->
         <a href="#">
            <button class="mx-auto lg:mx-0 bg-three text-white font-sans rounded-lg my-6 py-4 px-8 shadow-lg focus:outline-none focus:shadow-outline transform transition hover:scale-105 duration-300 ease-in-out">
               ¡Quiero aplicar!
            </button>
         </a>
         <?php elseif(Auth::user()->hasRole('Desarrollador')): ?>
         <a href="<?php echo e(url('login')); ?>">
            <button class="mx-auto lg:mx-0 bg-three text-white font-sans rounded-lg my-6 py-4 px-8 shadow-lg focus:outline-none focus:shadow-outline transform transition hover:scale-105 duration-300 ease-in-out">
               Inicia sesión para aplicar.
            </button>
         </a>
         <?php elseif(Auth::user()->hasAnyRole('Reclutador', 'Admin')): ?>;
         <a href="<?php echo e(route('admin.candidates.index')); ?>">
            <button class="mx-auto lg:mx-0 bg-three text-white font-sans rounded-lg my-6 py-4 px-8 shadow-lg focus:outline-none focus:shadow-outline transform transition hover:scale-105 duration-300 ease-in-out">
               Ver candidatos
            </button>
         </a>
         <?php endif; ?>
      </div>
   </div>
   <?php $__env->stopSection(); ?>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\plataforma\resources\views/vacancy.blade.php ENDPATH**/ ?>
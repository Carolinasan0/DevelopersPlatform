<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Aspirejobs</title>
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    </head>
    <body>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('navigation')->html();
} elseif ($_instance->childHasBeenRendered('zjP1zMl')) {
    $componentId = $_instance->getRenderedChildComponentId('zjP1zMl');
    $componentTag = $_instance->getRenderedChildComponentTagName('zjP1zMl');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('zjP1zMl');
} else {
    $response = \Livewire\Livewire::mount('navigation');
    $html = $response->html();
    $_instance->logRenderedChild('zjP1zMl', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <main>
            <div>
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </main>

        <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html><?php /**PATH C:\xampp\htdocs\plataforma\resources\views/layouts/web.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title', 'ASPIREJOBS'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Crear nuevo rol</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">

        <?php echo Form::open(['route' => 'admin.roles.store', 'autocomplete' => 'off']); ?>


        <?php echo $__env->make('admin.roles.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- BOTÓN CREAR -->
        <?php echo Form::submit('Crear rol', ['class' => 'btn btn-primary']); ?>


        <?php echo Form::close(); ?>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\plataforma\resources\views/admin/roles/create.blade.php ENDPATH**/ ?>


<?php $__env->startSection('code', 'Error'); ?>
<?php $__env->startSection('title', __('Acceso denegado')); ?>

<?php $__env->startSection('image'); ?>
<img src="https://image.freepik.com/free-vector/403-error-forbidden-with-police-concept-illustration_114360-1884.jpg" class="img-fluid" alt="imagen error 404">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('message', __('Lo sentimos, no tienes autorización para acceder a esta página.')); ?>
<?php echo $__env->make('errors::illustrated-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\plataforma\resources\views/errors/403.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title', 'ASPIREJOBS'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>¡Bienvenido/a!</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<p>Si usted es Administrador en este panel usted podrá:</br>
    - Ver, editar y eliminar los roles.</br>
    - Ver y editar el rol de sus usuarios.</br>
    - Ver, agregar, editar y eliminar categorías.</br>
    - Ver, agregar, editar y eliminar vacantes.</br>
    - Ver, agregar, editar y eliminar tecnologías.</br>
</p>
<p>Si usted es Reclutador en este panel usted podrá:</br>
    - Ver las categorías.</br>
    - Ver las tecnologías.</br>
    - Ver, agregar, editar y eliminar vacantes.</br>
</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    console.log('Hi!');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\plataforma\resources\views/admin/index.blade.php ENDPATH**/ ?>
<div class="bg-two shadow-lg rounded-lg text-center px-4 py-6">
    <a href="{{ route('vacancy.category', $category) }}">
        <h2 class="font-serif tracking-wide text-azul text-lg">{{ $category->name }}</h2>
    </a>
</div>
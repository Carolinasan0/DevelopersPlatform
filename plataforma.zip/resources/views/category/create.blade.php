@extends('layouts.web')

@section('content')
<h1>Aquí se creará una categoría</h1>
@endsection
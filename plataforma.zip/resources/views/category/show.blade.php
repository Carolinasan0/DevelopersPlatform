@extends('layouts.web')

@section('content')
<h1>Aquí van las vacantes de la categoría </h1>
@endsection